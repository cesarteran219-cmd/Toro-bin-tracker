import UIKit
import WebKit

final class WebViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    private var webView: WKWebView!

    override func loadView() {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.preferences.javaScriptCanOpenWindowsAutomatically = true

        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        view = webView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.047, green: 0.035, blue: 0.027, alpha: 1.0)

        guard let url = Bundle.main.url(forResource: "index", withExtension: "html") else {
            showFallback("Toro Tracker could not find its bundled web interface.")
            return
        }
        webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
    }

    private func showFallback(_ message: String) {
        webView.loadHTMLString("""
        <html><meta name="viewport" content="width=device-width,initial-scale=1">
        <body style="font-family:-apple-system;background:#0c0907;color:white;padding:30px">
        <h2>Toro Dumpsters</h2><p>\(message)</p></body></html>
        """, baseURL: nil)
    }

    // Toro jobsite navigation uses Google Maps, never Apple Maps.
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url,
              let scheme = url.scheme?.lowercased() else {
            decisionHandler(.allow)
            return
        }

        if scheme == "toromaps" {
            let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
            let address = components?.queryItems?.first(where: { $0.name == "q" })?.value ?? ""
            openGoogleMaps(address: address)
            decisionHandler(.cancel)
            return
        }

        if scheme == "tel" || scheme == "sms" || scheme == "mailto" {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
            return
        }

        decisionHandler(.allow)
    }

    private func openGoogleMaps(address: String) {
        guard !address.isEmpty else { return }
        let encoded = address.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? address

        // Try the native Google Maps app first.
        if let appURL = URL(string: "comgooglemaps://?q=\(encoded)") {
            UIApplication.shared.open(appURL, options: [:]) { success in
                if !success,
                   let webURL = URL(string: "https://www.google.com/maps/search/?api=1&query=\(encoded)") {
                    UIApplication.shared.open(webURL)
                }
            }
        }
    }
}
