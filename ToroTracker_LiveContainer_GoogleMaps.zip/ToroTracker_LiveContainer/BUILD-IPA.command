#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")"
ROOT="$(pwd)"
BUILD="$ROOT/build"
OUT="$ROOT/output"

echo ""
echo "============================================"
echo "      TORO TRACKER - LIVE CONTAINER BUILD"
echo "============================================"
echo ""

if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "ERROR: Xcode is required on this Mac."
  echo "Install/open Xcode first, then run this file again."
  read -n 1 -s -r -p "Press any key to close..."
  exit 1
fi

rm -rf "$BUILD" "$OUT"
mkdir -p "$OUT"

echo "Building Toro Tracker for iPhone..."
xcodebuild \
  -project "$ROOT/ToroTracker.xcodeproj" \
  -target ToroTracker \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath "$BUILD" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  build

APP="$BUILD/Build/Products/Release-iphoneos/ToroTracker.app"

if [ ! -d "$APP" ]; then
  echo "ERROR: Build finished but ToroTracker.app was not found."
  exit 1
fi

mkdir -p "$OUT/Payload"
cp -R "$APP" "$OUT/Payload/ToroTracker.app"

cd "$OUT"
ditto -c -k --sequesterRsrc --keepParent Payload ToroTracker-LiveContainer.ipa
rm -rf Payload

echo ""
echo "SUCCESS!"
echo "IPA created at:"
echo "$OUT/ToroTracker-LiveContainer.ipa"
echo ""
echo "Move that IPA to your iPhone, then in LiveContainer tap + and choose the IPA."
echo ""
open "$OUT" >/dev/null 2>&1 || true
